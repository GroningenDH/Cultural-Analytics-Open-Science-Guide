# SGG

Steam Game Genre


Data of this project comes from Steam official website - https://store.steampowered.com/charts.

The data scraped from this project can also be used to analysis questions like user preferences based on regions, platform preferences of Top 100 games and so on.


Contributors to this project:

BAI, Haozhe, S5171326 JIANG, Yingyue, S5202256 LIU, Ruohan, S5085462 WAN, Spring, S5343224 ZHAO, Yuanjie, S3581063
